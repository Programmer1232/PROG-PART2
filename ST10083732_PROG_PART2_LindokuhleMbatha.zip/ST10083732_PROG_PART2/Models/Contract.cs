﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ST10083732_PROG6212.Models
{

}



namespace ContractMonthlyClaimSystemWPF.Models
{
    public class Contract
    {
        public int Id { get; set; }

        //Get contract name
        public string ContractName { get; set; }

        //Predict date claim 
        public DateTime StartDate { get; set; }

        //predict claim deadline
        public DateTime EndDate { get; set; }
        //calculate the total number
        public decimal TotalValue { get; set; }
    }

    public enum ClaimStatus
    {
        Pending,
        Verified,
        Approved,
        Rejected
    }

    public class MonthlyClaim
    {
        public int Id { get; set; }

        //get contract id
        public int ContractId { get; set; }

        //Write claim date 
        public DateTime ClaimDate { get; set; }

        //calculate amount needed for claim
        public decimal Amount { get; set; }

        //Funeral Plan
        public string Description { get; set; }

        //show status of claim 
        public ClaimStatus Status { get; set; }


        public string SupportingDocumentPath { get; set; }

        //Name the contract
        public virtual Contract Contract { get; set; }
    }
}
